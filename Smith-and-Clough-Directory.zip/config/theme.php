<?php
return [
    'deepblue' => [
        'title' => 'Deep Blue',
        'path' => 'assets/uploads/theme/deepblue.png',
    ],


];
