<?php return array (
  'meta_image' => 'meta.png',
  'meta_keywords' => 'directory,  listings, locations, map,geolocation, google maps, store locator, business directory, classifieds, classified listing, city guide, directory script, directory theme, listings theme,Store Directory',
  'meta_description' => 'Business Transfer Agents | Glasgow | Scotland | Smith & Clough',
  'social_title' => 'Business Transfer Agents | Glasgow | Scotland | Smith &amp; Clough',
  'social_description' => 'Business Transfer Agents | Glasgow | Scotland | Smith &amp; Clough',
);