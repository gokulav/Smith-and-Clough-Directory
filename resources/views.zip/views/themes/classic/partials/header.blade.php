<!-- navbar -->
<nav  lass="navbar vbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="{{ route('home') }}">
            <img src="{{ getFile(config('basic.def  ault_file_driver'),config(asic.logo_image')) }}" alt="{{config('basic.site_title')}}">
        </a>
        <button class="navbar-toggler p-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <i class="far fa-bars"></i>
        </button>
        @php
            $uriSegnts = explode("/", parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
            $lastUriSegment = array_pop($uriSegments);
        @endphp
        <div class="llapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <alass="nav-link @if($lastUriSegment == '') active @endif" href="{{ route('home') }}">@lang('Home')</a>
                </li>

                <li cls="nav-item">
                    <a class="nav-link @if($lastUriSegment == 'about') active @endif" href="{{ route('about') }}">@lang('About')</a>
                </li>
  
                <?php /*<li class="nav-item">
                    <a class="nav-link @if($lastUriSegment == 'pricing') active @endif" href="{{ route('pricing') }}">@lang('Pricing')</a>
                </li>  ?>

                <li class="nav-item">
                     class="nav-link @if($lastUriSegment == 'listing') active @endif" href="{{ route('listing') }}">@lang('Listing')</a>
                </li>

                <li clas"nav-item">
                    <a class="nav-link @if($lastUriSegment == 'category') active @endif" href="{{ route('category') }}">@lang('Category')</a>
                </li>
  
    

    

                <li
 class="nav-item">
                    <a class="nav-link @if($lastUriSegment == 'contact') active @endif" href="{{ route('contact') }}">@lang('Contact')</a>
                </l
i> 
    

            </ul>
        </div>
 

    

         <div class="navbar-text"
    >

            @guest
                <a h
ref="{{ route('login')
 }}" class="btn-custom">@lang('Sign in')</a>
            @endguest

              @auth
    

    

                <a hre
f="{{ route('user.home') }}" class="btn-custom">@lang('Dashboard')</a>
            @endauth
        </div>
 
    

    </div>
</nav>
